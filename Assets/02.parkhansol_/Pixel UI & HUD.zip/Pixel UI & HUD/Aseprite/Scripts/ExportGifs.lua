local library = require("Library")
local sprite = app.activeSprite
if not sprite then
  return
end
local scriptPath = filename
local scriptDir = "."
if scriptPath then
  scriptDir = app.fs.filePath(scriptPath)
end
local spritesFolder = app.fs.joinPath(scriptDir, "Gifs")
print("GIF Export Initiated")
print("Script Directory: " .. scriptDir)
print("Target folder: " .. spritesFolder)
print("Sprite path: " .. sprite.filename)
local trim = library.getBoolParam("trim", true)
local trimCels = library.getBoolParam("trim-cels", true)
local ignoredLayers = library.getArrayParam("ignored-layers", {})
local ignoredTags = library.getArrayParam("ignored-tags", {})
local ignoredSlices = library.getArrayParam("ignored-slices", {})
local singleTag = library.getParam("tag", "")
local singleLayer = library.getParam("layer", "")
local singleSlice = library.getParam("slice", "")
local scale = library.getNumberParam("scale", 1)
local folder = library.getParam("folder", "{name}")
local filenameTemplate = library.getParam("filename", "{name}_{tagname}.gif")
local exportType = library.getParam("type", "tags")
print("exportType: " .. tostring(exportType))
print("singleTag: " .. tostring(singleTag))
print("singleLayer: " .. tostring(singleLayer))
print("singleSlice: " .. tostring(singleSlice))
print("ignoredLayers count: " .. tostring(#ignoredLayers))
print("ignoredTags count: " .. tostring(#ignoredTags))
print("ignoredSlices count: " .. tostring(#ignoredSlices))
print("Slices count on sprite: " .. tostring(#sprite.slices))
print("Tags count on sprite: " .. tostring(#sprite.tags))
folder = string.gsub(folder, "{name}", app.fs.fileTitle(sprite.filename))
if folder == "" then
  folder = app.fs.fileTitle(sprite.filename)
end
if not filenameTemplate:lower():match("%.gif$") then
  if filenameTemplate:match("%.[^%.]+$") then
    filenameTemplate = filenameTemplate:gsub("%.[^%.]+$", ".gif")
  else
    filenameTemplate = filenameTemplate .. ".gif"
  end
end
local baseFolder = app.fs.joinPath(spritesFolder, folder)
local function hideIgnoredLayers(parent, ignoredLayers)
  for _, layer in ipairs(parent.layers) do
    local shouldHide = false
    for _, ignored in ipairs(ignoredLayers) do
      if layer.name == ignored then
        shouldHide = true
        break
      end
    end
    if shouldHide then
      layer.isVisible = false
    else
      if layer.isGroup then
        hideIgnoredLayers(layer, ignoredLayers)
      end
    end
  end
end
local function hideLayersExcept(parent, targetName)
  local found = false
  for _, layer in ipairs(parent.layers) do
    if layer.name == targetName then
      layer.isVisible = true
      found = true
      if layer.isGroup then
        local function makeAllVisible(p)
          for _, l in ipairs(p.layers) do
            l.isVisible = true
            if l.isGroup then
              makeAllVisible(l)
            end
          end
        end
        makeAllVisible(layer)
      end
    else
      if layer.isGroup then
        local childFound = hideLayersExcept(layer, targetName)
        if childFound then
          layer.isVisible = true
          found = true
        else
          layer.isVisible = false
        end
      else
        layer.isVisible = false
      end
    end
  end
  return found
end
local function trimFrames(dupSprite, firstFrame, lastFrame)
  local numFrames = #dupSprite.frames
  for i = numFrames, 1, -1 do
    if i < firstFrame or i > lastFrame then
      dupSprite:deleteFrame(dupSprite.frames[i])
    end
  end
end
local function exportGifFile(dupSprite, outputFilename, scale)
  if #dupSprite.frames <= 1 then
    print("Skipping static file (1 frame): " .. outputFilename)
    return
  end
  if scale ~= 1 then
    dupSprite:resize(dupSprite.width * scale, dupSprite.height * scale)
  end
  app.fs.makeDirectory(app.fs.filePath(outputFilename))
  dupSprite:saveCopyAs(outputFilename)
end
local function resolveFilename(template, name, layerName, tagName, sliceName)
  local result = template
  if sliceName and sliceName ~= "" then
    if not string.find(result, "{slicename}") then
      result = string.gsub(result, "{name}", "{slicename}")
    end
  end
  if name then
    result = string.gsub(result, "{name}", name)
  end
  if layerName then
    result = string.gsub(result, "{layer}", layerName)
  end
  if tagName then
    local sanitized = tagName:gsub("[^%w_]", "")
    result = string.gsub(result, "{tag}", sanitized)
    result = string.gsub(result, "{tagname}", sanitized)
  else
    result = string.gsub(result, "_{tagname}", "")
    result = string.gsub(result, "_{tag}", "")
    result = string.gsub(result, "-{tagname}", "")
    result = string.gsub(result, "-{tag}", "")
    result = string.gsub(result, "{tagname}", "")
    result = string.gsub(result, "{tag}", "")
  end
  if sliceName then
    result = string.gsub(result, "{slicename}", sliceName)
  end
  return result
end
local function exportSheet()
  app.transaction(function()
    hideIgnoredLayers(sprite, ignoredLayers)
    if singleLayer ~= "" then
      hideLayersExcept(sprite, singleLayer)
    end
    local outName = resolveFilename(filenameTemplate, app.fs.fileTitle(sprite.filename), singleLayer, nil, nil)
    local outPath = app.fs.joinPath(baseFolder, outName)
    print("Exporting Sheet to: " .. outPath)
    exportGifFile(sprite, outPath, scale)
  end)
  app.command.Undo()
end
local function exportTags()
  if #sprite.tags == 0 then
    app.transaction(function()
      hideIgnoredLayers(sprite, ignoredLayers)
      if singleLayer ~= "" then
        hideLayersExcept(sprite, singleLayer)
      end
      local outName = resolveFilename(filenameTemplate, app.fs.fileTitle(sprite.filename), singleLayer, nil, nil)
      local outPath = app.fs.joinPath(baseFolder, outName)
      print("Exporting Tagless Sprite to: " .. outPath)
      exportGifFile(sprite, outPath, scale)
    end)
    app.command.Undo()
    return
  end
  for _, tag in ipairs(sprite.tags) do
    local shouldExport = true
    if singleTag ~= "" and singleTag ~= tag.name then
      shouldExport = false
    end
    for _, ignored in ipairs(ignoredTags) do
      if tag.name == ignored then
        shouldExport = false
        break
      end
    end
    if shouldExport then
      app.transaction(function()
        hideIgnoredLayers(sprite, ignoredLayers)
        if singleLayer ~= "" then
          hideLayersExcept(sprite, singleLayer)
        end
        trimFrames(sprite, tag.fromFrame.frameNumber, tag.toFrame.frameNumber)
        local outName = resolveFilename(filenameTemplate, app.fs.fileTitle(sprite.filename), singleLayer, tag.name, nil)
        local outPath = app.fs.joinPath(baseFolder, outName)
        print("Exporting Tag " .. tag.name .. " to: " .. outPath)
        exportGifFile(sprite, outPath, scale)
      end)
      app.command.Undo()
    end
  end
end
local function exportSlices()
  for _, slice in ipairs(sprite.slices) do
    local shouldExport = true
    if singleSlice ~= "" and singleSlice ~= slice.name then
      shouldExport = false
    end
    for _, ignored in ipairs(ignoredSlices) do
      if slice.name == ignored then
        shouldExport = false
        break
      end
    end
    if shouldExport then
      app.transaction(function()
        hideIgnoredLayers(sprite, ignoredLayers)
        sprite:crop(slice.bounds)
        local outName = resolveFilename(filenameTemplate, app.fs.fileTitle(sprite.filename), nil, nil, slice.name)
        local outPath = app.fs.joinPath(baseFolder, outName)
        print("Exporting Slice " .. slice.name .. " to: " .. outPath)
        exportGifFile(sprite, outPath, scale)
      end)
      app.command.Undo()
    end
  end
end
local function exportLayerSlices()
  for _, slice in ipairs(sprite.slices) do
    local shouldExport = true
    if singleSlice ~= "" and singleSlice ~= slice.name then
      shouldExport = false
    end
    for _, ignored in ipairs(ignoredSlices) do
      if slice.name == ignored then
        shouldExport = false
        break
      end
    end
    if shouldExport then
      app.transaction(function()
        hideIgnoredLayers(sprite, ignoredLayers)
        if singleLayer ~= "" then
          hideLayersExcept(sprite, singleLayer)
        end
        sprite:crop(slice.bounds)
        local outName = resolveFilename(filenameTemplate, app.fs.fileTitle(sprite.filename), singleLayer, nil, slice.name)
        local outPath = app.fs.joinPath(baseFolder, outName)
        print("Exporting Layer Slice " .. slice.name .. " to: " .. outPath)
        exportGifFile(sprite, outPath, scale)
      end)
      app.command.Undo()
    end
  end
end
local function exportSliceTags()
  print("Entering exportSliceTags")
  if #sprite.tags == 0 then
    for _, slice in ipairs(sprite.slices) do
      local shouldExportSlice = true
      if singleSlice ~= "" and singleSlice ~= slice.name then
        shouldExportSlice = false
      end
      for _, ignored in ipairs(ignoredSlices) do
        if slice.name == ignored then
          shouldExportSlice = false
          break
        end
      end
      print("Slice " .. tostring(slice.name) .. " shouldExportSlice: " .. tostring(shouldExportSlice))
      if shouldExportSlice then
        app.transaction(function()
          hideIgnoredLayers(sprite, ignoredLayers)
          if singleLayer ~= "" then
            hideLayersExcept(sprite, singleLayer)
          end
          sprite:crop(slice.bounds)
          local outName = resolveFilename(filenameTemplate, app.fs.fileTitle(sprite.filename), singleLayer, nil, slice.name)
          local outPath = app.fs.joinPath(baseFolder, outName)
          print("Exporting Slice " .. slice.name .. " to: " .. outPath)
          exportGifFile(sprite, outPath, scale)
        end)
        app.command.Undo()
      end
    end
    return
  end
  for _, slice in ipairs(sprite.slices) do
    local shouldExportSlice = true
    if singleSlice ~= "" and singleSlice ~= slice.name then
      shouldExportSlice = false
    end
    for _, ignored in ipairs(ignoredSlices) do
      if slice.name == ignored then
        shouldExportSlice = false
        break
      end
    end
    print("Slice " .. tostring(slice.name) .. " shouldExportSlice: " .. tostring(shouldExportSlice))
    if shouldExportSlice then
      for _, tag in ipairs(sprite.tags) do
        local shouldExportTag = true
        if singleTag ~= "" and singleTag ~= tag.name then
          shouldExportTag = false
        end
        for _, ignored in ipairs(ignoredTags) do
          if tag.name == ignored then
            shouldExportTag = false
            break
          end
        end
        print("  Tag " .. tostring(tag.name) .. " shouldExportTag: " .. tostring(shouldExportTag))
        if shouldExportTag then
          app.transaction(function()
            hideIgnoredLayers(sprite, ignoredLayers)
            if singleLayer ~= "" then
              hideLayersExcept(sprite, singleLayer)
            end
            sprite:crop(slice.bounds)
            trimFrames(sprite, tag.fromFrame.frameNumber, tag.toFrame.frameNumber)
            local outName = resolveFilename(filenameTemplate, app.fs.fileTitle(sprite.filename), singleLayer, tag.name, slice.name)
            local outPath = app.fs.joinPath(baseFolder, outName)
            print("Exporting Slice Tag (" .. slice.name .. " / " .. tag.name .. ") to: " .. outPath)
            exportGifFile(sprite, outPath, scale)
          end)
          app.command.Undo()
        end
      end
    end
  end
end
local function exportFolderTags()
  local hasGroups = false
  for _, group in ipairs(sprite.layers) do
    if group.isGroup then
      hasGroups = true
      local shouldExportGroup = true
      if singleLayer ~= "" and singleLayer ~= group.name then
        shouldExportGroup = false
      end
      for _, ignored in ipairs(ignoredLayers) do
        if group.name == ignored then
          shouldExportGroup = false
          break
        end
      end
      if shouldExportGroup then
        if #sprite.tags == 0 then
          app.transaction(function()
            hideIgnoredLayers(sprite, ignoredLayers)
            hideLayersExcept(sprite, group.name)
            local outName = resolveFilename(filenameTemplate, app.fs.fileTitle(sprite.filename), group.name, nil, nil)
            local outPath = app.fs.joinPath(baseFolder, outName)
            print("Exporting Folder " .. group.name .. " to: " .. outPath)
            exportGifFile(sprite, outPath, scale)
          end)
          app.command.Undo()
        else
          for _, tag in ipairs(sprite.tags) do
            local shouldExportTag = true
            if singleTag ~= "" and singleTag ~= tag.name then
              shouldExportTag = false
            end
            for _, ignored in ipairs(ignoredTags) do
              if tag.name == ignored then
                shouldExportTag = false
                break
              end
            end
            if shouldExportTag then
              if not library.isLayerTagEmpty(sprite, tag, group) then
                app.transaction(function()
                  hideIgnoredLayers(sprite, ignoredLayers)
                  hideLayersExcept(sprite, group.name)
                  trimFrames(sprite, tag.fromFrame.frameNumber, tag.toFrame.frameNumber)
                  local outName = resolveFilename(filenameTemplate, app.fs.fileTitle(sprite.filename), group.name, tag.name, nil)
                  local outPath = app.fs.joinPath(baseFolder, outName)
                  print("Exporting Folder Tag (" .. group.name .. " / " .. tag.name .. ") to: " .. outPath)
                  exportGifFile(sprite, outPath, scale)
                end)
                app.command.Undo()
              end
            end
          end
        end
      end
    end
  end
  if not hasGroups then
    exportTags()
  end
end
local function exportLayers()
  for _, layer in ipairs(sprite.layers) do
    local shouldExport = true
    if singleLayer ~= "" and singleLayer ~= layer.name then
      shouldExport = false
    end
    for _, ignored in ipairs(ignoredLayers) do
      if layer.name == ignored then
        shouldExport = false
        break
      end
    end
    if shouldExport then
      app.transaction(function()
        hideIgnoredLayers(sprite, ignoredLayers)
        hideLayersExcept(sprite, layer.name)
        local outName = resolveFilename(filenameTemplate, app.fs.fileTitle(sprite.filename), layer.name, nil, nil)
        local outPath = app.fs.joinPath(baseFolder, outName)
        print("Exporting Layer " .. layer.name .. " to: " .. outPath)
        exportGifFile(sprite, outPath, scale)
      end)
      app.command.Undo()
    end
  end
end
if exportType == "sheet" then
  exportSheet()
elseif exportType == "tags" then
  exportTags()
elseif exportType == "slices" then
  exportSlices()
elseif exportType == "layer_slices" then
  exportLayerSlices()
elseif exportType == "slice_tags" then
  exportSliceTags()
elseif exportType == "folder_tags" then
  exportFolderTags()
elseif exportType == "layers" then
  exportLayers()
else
  print("Unrecognized exportType: " .. tostring(exportType))
end
