$asepritePath = "D:/Program Files (x86)/Steam/steamapps/common/Aseprite/Aseprite.exe"
if (-not (Test-Path $asepritePath)) {
    $asepritePath = "Aseprite"
}
$exportGifs = "./ExportGifs.lua"
$jsonFile = "exports.json"
if (-not (Test-Path $jsonFile)) {
    Write-Host "File not found: $jsonFile" -ForegroundColor Red
    Exit
}
$config = Get-Content -Raw $jsonFile | ConvertFrom-Json
$directory = $config.directory
function ShowMenu {
    Write-Host "Available exports:"
    $i = 1
    foreach ($exp in $config.exports) {
        Write-Host "$i`t$($exp.file)"
        $i++
    }
}
while ($true) {
    ShowMenu
    $selection = Read-Host "Enter the number(s) of the exports to process (separated by spaces), or press Enter to export all"
    $selectedExports = @()
    if ([string]::IsNullOrWhiteSpace($selection)) {
        $selectedExports = $config.exports
    } else {
        $indices = $selection -split "\s+"
        foreach ($index in $indices) {
            $parsedIndex = 0
            if ([int]::TryParse($index, [ref]$parsedIndex)) {
                if ($parsedIndex -ge 1 -and $parsedIndex -le $config.exports.Count) {
                    $selectedExports += $config.exports[$parsedIndex - 1]
                } else {
                    Write-Host "Invalid selection: $index" -ForegroundColor Yellow
                }
            } else {
                Write-Host "Invalid selection: $index" -ForegroundColor Yellow
            }
        }
    }
    if ($selectedExports.Count -eq 0) {
        continue
    }
    foreach ($exp in $selectedExports) {
        $file = $exp.file
        Write-Host "Sprite: $file" -ForegroundColor Cyan
        foreach ($preset in $exp.presets) {
            $dest = ".\Gifs"
            $presetType = $preset.type
            $filename = if ($preset.filename) { $preset.filename } else { "{name}.png" }
            $folder = if ($preset.folder) { $preset.folder } else { "{name}" }
            $scale = if ($preset.scale) { $preset.scale } else { 1 }
            $tag = if ($preset.tag) { $preset.tag } else { "" }
            $layer = if ($preset.layer) { $preset.layer } else { "" }
            $slice = if ($preset.slice) { $preset.slice } else { "" }
            $splitLayers = if ($preset.splitLayers) { $preset.splitLayers } else { "" }
            $ignoredLayers = if ($preset.ignored_layers) { $preset.ignored_layers -join "," } else { "" }
            $ignoredSlices = if ($preset.ignored_slices) { $preset.ignored_slices -join "," } else { "" }
            $ignoredTags = if ($preset.ignored_tags) { $preset.ignored_tags -join "," } else { "" }
            $filepath = Join-Path $directory "$file.aseprite"
            Write-Host "Exporting $presetType from $filepath to $dest\$folder\$filename" -ForegroundColor Gray
            $args = @(
                "-b",
                $filepath,
                "--script-param", "sprites-folder=$dest",
                "--script-param", "scale=$scale",
                "--script-param", "ignored-layers=$ignoredLayers",
                "--script-param", "ignored-slices=$ignoredSlices",
                "--script-param", "ignored-tags=$ignoredTags",
                "--script-param", "tag=$tag",
                "--script-param", "layer=$layer",
                "--script-param", "slice=$slice",
                "--script-param", "filename=$filename",
                "--script-param", "folder=$folder",
                "--script-param", "split-layers=$splitLayers",
                "--script-param", "type=$presetType",
                "--script", $exportGifs
            )
            $process = Start-Process -FilePath $asepritePath -ArgumentList $args -NoNewWindow -PassThru -Wait
        }
        Write-Host ""
    }
    Write-Host "Process completed!" -ForegroundColor Green
    Write-Host "---"
}
